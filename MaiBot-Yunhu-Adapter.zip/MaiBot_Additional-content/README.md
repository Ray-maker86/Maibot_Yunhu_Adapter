# Maibot Yunhu Adapter
这个Adapter是麦麦的云湖适配器，提供了对云湖机器人的支持。

## requirements
- Python 3.10+ (与麦麦本体相同)